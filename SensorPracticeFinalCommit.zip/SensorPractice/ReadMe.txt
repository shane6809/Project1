I used the light sensor.  My project changes colors based on the amount of light that the light sensor senses.  
The colors go from dark for easier night time reading, and gradually increase to brighter colors for easier reading
when the light senses bright light.  A toast is used to show the lux values.  This value is consitent with the lux
and constantly shows the value from 0.0 to 40000.00.  I plan on implementing a version of this for my final project, and have also included
many colors in colors.xml.